var capitalCity = ["Nepal": "Kathmandu", "Italy": "Rome", "England": "London"]
print(capitalCity)
// dictionary with keys and values of different data types
var numbers = [1: "One", 2: "Two", 3: "Three"]
print(numbers)

//Add Elements to a Dictionary
print("Initial Dictionary: ",capitalCity)
capitalCity["Japan"] = "Tokyo"
print("Updated Dictionary: ",capitalCity)
print(capitalCity["Japan"])

//Change Value of Dictionary
var studentID = [111: "Eric", 112: "Kyle", 113: "Butters"]
print("Initial Dictionary: ", studentID)
studentID[112] = "Stan"
print("Updated Dictionary: ", studentID)

//Access Elements from Dictionary
var cities = ["Nepal":"Kathmandu", "China":"Beijing", "Japan":"Tokyo"]
print("Dictionary: ", cities)

// cities.keys return all keys of cities
var countryName  = Array(cities.keys)
print("Keys: ", countryName)

// cities.values return all values of cities
var countryName1  = Array(cities.values)
print("Values: ", countryName1)

//Remove an Element from a Dictionary
print("Initial Dictionary: ", studentID)
var removedValue  = studentID.removeValue(forKey: 112)
print("Dictionary After removeValue(): ", studentID)
